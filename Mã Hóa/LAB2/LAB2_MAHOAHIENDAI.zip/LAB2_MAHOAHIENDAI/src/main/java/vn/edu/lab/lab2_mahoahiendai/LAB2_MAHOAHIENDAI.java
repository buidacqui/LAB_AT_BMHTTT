/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package vn.edu.lab.lab2_mahoahiendai;

/**
 *
 * @author buidacqui
 */
public class LAB2_MAHOAHIENDAI {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
