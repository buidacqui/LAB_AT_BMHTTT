package week_02;

public final class RC4Cipher {

    private RC4Cipher() {}

    private static byte[] apply(byte[] data, byte[] key) {

        if (key.length == 0 || key.length > 256) {
            throw new IllegalArgumentException(
                "Khóa RC4 phải có 1 - 256 byte."
            );
        }

        int[] s = new int[256];

        for (int i = 0; i < 256; i++) {
            s[i] = i;
        }

        int j = 0;

        for (int i = 0; i < 256; i++) {
            j = (j + s[i] + (key[i % key.length] & 0xff)) & 255;

            int temp = s[i];
            s[i] = s[j];
            s[j] = temp;
        }

        int i = 0;
        j = 0;

        byte[] output = new byte[data.length];

        for (int n = 0; n < data.length; n++) {
            i = (i + 1) & 255;
            j = (j + s[i]) & 255;

            int temp = s[i];
            s[i] = s[j];
            s[j] = temp;

            int k = s[(s[i] + s[j]) & 255];

            output[n] = (byte) (data[n] ^ k);
        }

        return output;
    }

    public static String encrypt(
            String plaintext, String key) {

        CipherUtil.requireKey(key);

        return CipherUtil.hex(
            apply(
                CipherUtil.utf8(plaintext),
                CipherUtil.utf8(key)
            )
        );
    }

    public static String decrypt(
            String hexCiphertext, String key) {

        CipherUtil.requireKey(key);

        return CipherUtil.text(
            apply(
                CipherUtil.fromHex(hexCiphertext),
                CipherUtil.utf8(key)
            )
        );
    }
}
