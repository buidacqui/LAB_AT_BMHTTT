package week_02;

import java.util.Arrays;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public final class DESCipher {

    private DESCipher() {}

    private static SecretKeySpec key(String value) {
        CipherUtil.requireKey(value);

        byte[] bytes = CipherUtil.utf8(value);

        if (bytes.length != 8) {
            throw new IllegalArgumentException(
                "Khóa DES phải đúng 8 byte. Hiện có "
                + bytes.length + " byte."
            );
        }

        return new SecretKeySpec(bytes, "DES");
    }

    public static String encrypt(
            String plaintext, String password)
            throws Exception {

        byte[] iv = CipherUtil.randomBytes(8);

        Cipher cipher = Cipher.getInstance(
            "DES/CBC/PKCS5Padding"
        );

        cipher.init(
            Cipher.ENCRYPT_MODE,
            key(password),
            new IvParameterSpec(iv)
        );

        byte[] encrypted = cipher.doFinal(
            CipherUtil.utf8(plaintext)
        );

        return CipherUtil.b64(
            CipherUtil.concat(iv, encrypted)
        );
    }

    public static String decrypt(
            String ciphertext, String password)
            throws Exception {

        byte[] all = CipherUtil.fromB64(ciphertext);

        if (all.length < 16) {
            throw new IllegalArgumentException(
                "Bản mã quá ngắn hoặc bị hỏng."
            );
        }

        byte[] iv = Arrays.copyOfRange(all, 0, 8);
        byte[] encrypted = Arrays.copyOfRange(
            all, 8, all.length
        );

        Cipher cipher = Cipher.getInstance(
            "DES/CBC/PKCS5Padding"
        );

        cipher.init(
            Cipher.DECRYPT_MODE,
            key(password),
            new IvParameterSpec(iv)
        );

        return CipherUtil.text(
            cipher.doFinal(encrypted)
        );
    }
}
